package com.minsait.onesait.platform.examples.iotclient4springboot.repository;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minsait.onesait.platform.examples.iotclient4springboot.model.Ticket;
import com.minsait.onesait.platform.examples.iotclient4springboot.model.TicketOntology;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CheckTicketRepository {

	@Autowired
	private TicketsRepository ticketRepository;

	@PostConstruct
	public void testCRUD() {
		List<TicketOntology> tickets = null;
		try {
			tickets = ticketRepository.getAllFieldsOfTickets();
			log.info("tickets _id,*, returned:" + tickets.size());
			tickets = ticketRepository.getFieldsOfTickets();
			log.info("tickets only several fields, returned:" + tickets.size());

			tickets = ticketRepository.getTicketsPendingByNativeQuery();
			log.info("tickets in native way, returned:" + tickets.size());
			tickets = ticketRepository.getTicketsPendingByNativeQueryAnotherWay();
			log.info("tickets in native way, returned:" + tickets.size());

			int numberOfTickets = ticketRepository.getNumberOfTickets();
			log.info("At first there is " + numberOfTickets + " tickets");

			TicketOntology tOnt = getTicketOntology();
			String idTicket = ticketRepository.insertTicket(tOnt);
			log.info("Ticket inserted");

			numberOfTickets = ticketRepository.getNumberOfTickets();
			log.info("Now there is " + numberOfTickets + " tickets");

			TicketOntology tInserted = ticketRepository.getTicketById(idTicket);

			tInserted.getTicket().setIdentification("IdChangedinUpdate");
			ticketRepository.updateTicket(idTicket, tInserted);
			TicketOntology tUpdated = ticketRepository.getTicketById(idTicket);
			if (!tUpdated.getTicket().getIdentification().equals("IdChangedinUpdate"))
				throw new Exception("Error en updated");

			tickets = ticketRepository.getAllTickets();
			log.info("Number of tickets: " + tickets.size());
			tickets = ticketRepository.getTicketsByUser("developer");
			log.info("Number of tickets: " + tickets.size());

			ticketRepository.deleteTicket(idTicket);
			int finalNumberOfTickets = ticketRepository.getNumberOfTickets();
			;
			log.info("Finally there is " + finalNumberOfTickets + " tickets");
			if (numberOfTickets != finalNumberOfTickets + 1)
				throw new Exception("Error in number of tickets");

		} catch (Exception e) {
			log.error("Captured exception", e);
		}
	}

	private JsonNode getCoordinates() throws Exception {
		String jsonString = "{\"coordinates\":{\"latitude\":20.408,\"longitude\":12.371},\"type\":\"Point\"}}";
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readTree(jsonString);
		return actualObj;
	}

	private JsonNode getFile() throws Exception {
		String jsonString = "{\"data\":\"\",\"media\":{\"name\":\"\",\"storageArea\":\"SERIALIZED\",\"binaryEncoding\":\"Base64\",\"mime\":\"application/pdf\"}}";
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readTree(jsonString);
		return actualObj;
	}

	private TicketOntology getTicketOntology() throws Exception {
		TicketOntology tOnt = new TicketOntology();
		Ticket ticket = new Ticket();
		ticket.setCoordinates(getCoordinates());
		ticket.setDescription("Example Ticket");
		ticket.setEmail("lmgracia@indra,es");
		ticket.setFile(getFile());
		ticket.setIdentification("ExampleId");
		ticket.setResponse_via("C/Tordo 30");
		ticket.setName("Example Ticket");
		ticket.setStatus("OK");
		ticket.setType(null);
		tOnt.setTicket(ticket);
		return tOnt;
	}
}