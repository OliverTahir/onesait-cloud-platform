package com.minsait.onesait.platform.examples.iotclient4springboot.repository;

import java.util.List;

import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerDelete;
import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerInsert;
import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerParam;
import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerQuery;
import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerRepository;
import com.minsait.onesait.platform.client.springboot.aspect.IoTBrokerUpdate;
import com.minsait.onesait.platform.comms.protocol.enums.SSAPQueryType;
import com.minsait.onesait.platform.examples.iotclient4springboot.model.TicketOntology;

@IoTBrokerRepository("Ticket")
public interface TicketsRepository {

	@IoTBrokerQuery("select * from Ticket")
	List<TicketOntology> getAllTickets();

	@IoTBrokerQuery("select * from Ticket where contextData.user='$user'")
	List<TicketOntology> getTicketsByUser(@IoTBrokerParam("$user") String user);

	@IoTBrokerQuery("select _id,* from Ticket")
	List<TicketOntology> getAllFieldsOfTickets();

	@IoTBrokerQuery("select _id,Ticket.Status from Ticket")
	List<TicketOntology> getFieldsOfTickets();

	@IoTBrokerQuery("select * from Ticket where _id=OID(\"$id\")")
	TicketOntology getTicketById(@IoTBrokerParam("$id") String id);

	@IoTBrokerQuery(value = "{\"Ticket.Status\":\"PENDING\"}", queryType = SSAPQueryType.NATIVE)
	List<TicketOntology> getTicketsPendingByNativeQuery();

	@IoTBrokerQuery(value = "db.Ticket.find({'Ticket.Status':'PENDING'})", queryType = SSAPQueryType.NATIVE)
	List<TicketOntology> getTicketsPendingByNativeQueryAnotherWay();

	@IoTBrokerQuery("select count(*) from Ticket")
	int getNumberOfTickets();

	@IoTBrokerInsert
	String insertTicket(TicketOntology ticket);

	@IoTBrokerUpdate
	void updateTicket(String idTicket, TicketOntology ticket);

	@IoTBrokerDelete
	void deleteTicket(String id);
}
