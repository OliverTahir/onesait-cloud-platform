package com.minsait.onesait.platform.examples.iotclient4springboot.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class Ticket {

	@JsonProperty("Identification")
	private String identification;
	@JsonProperty("Status")
	private String status;
	@JsonProperty("Email")
	private String email;
	@JsonProperty("Name")
	private String name;
	@JsonProperty("Response_via")
	private String response_via;

	@JsonProperty("Coordinates")
	private JsonNode coordinates;

	@JsonProperty("Type")
	private String type;
	@JsonProperty("Description")
	private String description;

	@JsonProperty("File")
	private JsonNode file;

}
